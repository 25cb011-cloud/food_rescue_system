# Stage 1 files

Copy these into your Vite project (see the steps in the chat):
- index.html, vite.config.ts  -> replace the ones in the project root
- src/index.css, src/main.tsx, src/App.tsx -> replace the ones in src/
- src/components/*, src/pages/*  -> new folders inside src/
Delete src/App.css and src/assets if they exist (not used).
